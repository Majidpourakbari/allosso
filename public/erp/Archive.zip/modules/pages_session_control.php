
<?php if(!isset($_COOKIE['bjslcnr'])){ header('location:login.php');} ?>
