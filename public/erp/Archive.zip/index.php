<?php include 'views/headin.php' ?>

<body>
    <div class="container">
        <div class="login-container">
            <h2 class="login-title"><i class="fas fa-user-circle"></i>Welcome Back</h2>
            <div id="alert-message" class="alert" role="alert"></div>
            <form id="loginForm">
                <div class="form-floating mb-3">
                    <i class="fas fa-envelope input-icon"></i>
                    <input type="email" class="form-control" id="email" name="email" placeholder="name@example.com" required>
                    <label for="email">Email address</label>
                </div>
                <div class="form-floating mb-4">
                    <i class="fas fa-lock input-icon"></i>
                    <input type="password" class="form-control" id="password" name="password" placeholder="Password" required>
                    <label for="password">Password</label>
                    <i class="fas fa-eye password-toggle" onclick="togglePassword()"></i>
                </div>
                <button type="submit" class="btn btn-primary btn-login w-100">
                    <i class="fas fa-sign-in-alt me-2"></i>Sign In
                </button>
            </form>

            <div class="social-login">
                <p>Or continue with</p>
                <div class="social-icons">
                    <a href="#" class="google"><i class="fab fa-google"></i></a>
                    <a href="#" class="facebook"><i class="fab fa-facebook-f"></i></a>
                    <a href="#" class="twitter"><i class="fab fa-twitter"></i></a>
                </div>
            </div>
        </div>
    </div>

    <script>
        function togglePassword() {
            const passwordInput = document.getElementById('password');
            const icon = document.querySelector('.password-toggle');
            
            if (passwordInput.type === 'password') {
                passwordInput.type = 'text';
                icon.classList.remove('fa-eye');
                icon.classList.add('fa-eye-slash');
            } else {
                passwordInput.type = 'password';
                icon.classList.remove('fa-eye-slash');
                icon.classList.add('fa-eye');
            }
        }

        $(document).ready(function() {
            $('#loginForm').on('submit', function(e) {
                e.preventDefault();
                
                $.ajax({
                    type: 'POST',
                    url: 'process_login.php',
                    data: {
                        email: $('#email').val(),
                        password: $('#password').val()
                    },
                    dataType: 'json',
                    success: function(result) {
                        if (result.success) {
                            window.location.href = 'dashboard';
                        } else {
                            $('#alert-message')
                                .removeClass('alert-success')
                                .addClass('alert-danger')
                                .html(result.message)
                                .show();
                        }
                    },
                    error: function(xhr, status, error) {
                        $('#alert-message')
                            .removeClass('alert-success')
                            .addClass('alert-danger')
                            .html('An error occurred. Please try again.')
                            .show();
                        console.error('Login error:', error);
                    }
                });
            });
        });
    </script>
</body>
</html> 


<?php include 'views/footer.php' ?>